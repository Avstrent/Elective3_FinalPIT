<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Manila');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit();

// Get JSON input
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || !isset($data['rfid_data'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing rfid_data"]);
    exit();
}

$rfid = trim($data['rfid_data']);
if ($rfid === '') {
    http_response_code(400);
    echo json_encode(["error" => "Empty RFID"]);
    exit();
}

// Connect to DB
$conn = new mysqli("localhost", "root", "", "it414_db_no_cap");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "DB connection failed"]);
    exit();
}

$rfid_safe = $conn->real_escape_string($rfid);
$time_log = date('Y-m-d h:i:s A');

// Check if RFID exists
$res = $conn->query("SELECT rfid_status FROM rfid_reg WHERE rfid_data='$rfid_safe'");

if ($res && $res->num_rows > 0) {
    // RFID found, toggle status
    $row = $res->fetch_assoc();
    $current_status = intval($row['rfid_status']);
    $new_status = $current_status ? "0" : "1";

    // Update rfid_reg
    $conn->query("UPDATE rfid_reg SET rfid_status='$new_status' WHERE rfid_data='$rfid_safe'");

    // Insert log with status
    $stmt = $conn->prepare("INSERT INTO rfid_logs (time_log, rfid_data, rfid_status) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $time_log, $rfid_safe, $new_status);
    $stmt->execute();
    $stmt->close();

    $response_status = $new_status;

} else {
    // RFID not found, insert NULL rfid_status
    $stmt = $conn->prepare("INSERT INTO rfid_logs (time_log, rfid_data, rfid_status) VALUES (?, ?, NULL)");
    $stmt->bind_param("ss", $time_log, $rfid_safe);
    $stmt->execute();
    $stmt->close();

    $response_status = null;
}

echo json_encode([
    "rfid_data" => $rfid,
    "rfid_status" => $response_status
]);

$conn->close();
?>
