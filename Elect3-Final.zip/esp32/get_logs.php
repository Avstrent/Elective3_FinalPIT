<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$conn = new mysqli("localhost", "root", "", "it414_db_no_cap");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}
$conn->set_charset("utf8mb4");

// Fetch from rfid_logs only
$sql = "
  SELECT
    rfid_data AS rfid,
    rfid_status AS status,
    time_log AS date_time
  FROM rfid_logs
  ORDER BY time_log DESC
";

$result = $conn->query($sql);
if (!$result) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => $conn->error]);
    exit();
}

$logs = [];
while ($row = $result->fetch_assoc()) {
    $status = $row["status"];
    $rfid_message = ($status === null || $status === "" || strtoupper($status) === "NULL")
        ? "RFID NOT FOUND"
        : "RFID FOUND";

    $logs[] = [
        "rfid"         => $row["rfid"],
        "status"       => is_numeric($status) ? (int)$status : $status,
        "date_time"    => $row["date_time"],
        "rfid_message" => $rfid_message
    ];
}

echo json_encode($logs, JSON_UNESCAPED_UNICODE);
$conn->close();
?>
