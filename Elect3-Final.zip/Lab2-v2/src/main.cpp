#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <WiFiMulti.h>
#include <HTTPClient.h>
#include <PubSubClient.h>
#include <MFRC522.h>

#define SS_PIN 5
#define RST_PIN 0

MFRC522 rfid(SS_PIN, RST_PIN);
WiFiMulti wifiMulti;
WiFiClient espClient;
PubSubClient mqtt(espClient);

const char *MQTT_BROKER = "192.168.0.128";
const uint16_t MQTT_PORT = 1883;
const char *MQTT_TOPIC = "RFID_LOGIN";
const char *MQTT_CLIENT_ID = "mqttx_841f3abe";

const char *SERVER_URL = "http://192.168.0.128/esp32/insert.php";

String rfidData = "";
unsigned long lastReadTime = 0;
const unsigned long readInterval = 2000;
bool wifiConnected = false;

void connectToWiFi()
{
  int attempts = 0;
  while (wifiMulti.run() != WL_CONNECTED && attempts < 15)
  {
    Serial.print(".");
    delay(500);
    attempts++;
  }
  if (wifiMulti.run() == WL_CONNECTED)
  {
    wifiConnected = true;
    Serial.println("\nWiFi connected successfully!");
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.println();
  }
  else
  {
    wifiConnected = false;
    Serial.println("\nFailed to connect to WiFi\n");
  }
}

void ensureMQTT()
{
  while (!mqtt.connected())
  {
    Serial.print("Connecting to MQTT...");
    if (mqtt.connect(MQTT_CLIENT_ID))
    {
      Serial.println("connected");
    }
    else
    {
      Serial.print("failed, rc=");
      Serial.println(mqtt.state());
      delay(1000);
    }
  }
}

void sendRFIDData(String rfidData)
{
  if (WiFi.status() != WL_CONNECTED)
  {
    Serial.println("Cannot send data - WiFi disconnected");
    return;
  }

  HTTPClient http;
  String jsonPayload = "{\"rfid_data\":\"" + rfidData + "\"}";
  Serial.println("Attempting to send data to server...");
  Serial.print("JSON Payload: ");
  Serial.println(jsonPayload);

  if (!http.begin(SERVER_URL))
  {
    Serial.println("HTTPClient begin() failed");
    http.end();
    return;
  }
  http.addHeader("Content-Type", "application/json");
  int httpResponseCode = http.POST(jsonPayload);

  if (httpResponseCode > 0)
  {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    String response = http.getString();
    Serial.print("Server response: ");
    Serial.println(response);

    if (response.indexOf("RFID NOT FOUND") >= 0)
    {
      Serial.println("RFID NOT FOUND → No MQTT publish");
      http.end();
      return;
    }

    if (response.indexOf("\"rfid_status\":\"1\"") >= 0 || response.indexOf("\"rfid_status\":1") >= 0)
    {
      ensureMQTT();
      mqtt.publish(MQTT_TOPIC, "1");
      Serial.println("Published to MQTT (RFID_LOGIN): 1");
    }
    else if (response.indexOf("\"rfid_status\":\"0\"") >= 0 || response.indexOf("\"rfid_status\":0") >= 0)
    {
      ensureMQTT();
      mqtt.publish(MQTT_TOPIC, "0");
      Serial.println("Published to MQTT (RFID_LOGIN): 0");
    }
    else
    {
      Serial.println("Response unclear → No MQTT publish");
    }
  }
  else
  {
    Serial.print("HTTP POST failed, code: ");
    Serial.println(httpResponseCode);
    Serial.print("Error: ");
    Serial.println(http.errorToString(httpResponseCode));
  }

  http.end();
}

void readRFID()
{
  if (millis() - lastReadTime < readInterval)
  {
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    return;
  }

  rfidData = "";
  for (byte i = 0; i < rfid.uid.size; i++)
  {
    rfidData.concat(String(rfid.uid.uidByte[i] < 0x10 ? "0" : ""));
    rfidData.concat(String(rfid.uid.uidByte[i], HEX));
  }
  rfidData.toUpperCase();

  Serial.println();
  Serial.print("RFID Detected: ");
  Serial.println(rfidData);

  sendRFIDData(rfidData);

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
  lastReadTime = millis();
}

void setup()
{
  Serial.begin(115200);
  while (!Serial)
    ;

  SPI.begin(18, 19, 23);
  rfid.PCD_Init();
  Serial.println("RFID reader initialized");

  WiFi.mode(WIFI_STA);
  wifiMulti.addAP("Cloud Control Network", "ccv7network");
  wifiMulti.addAP("azzy_guest", "!mwwu@x1gH");

  connectToWiFi();

  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  ensureMQTT();

  Serial.println("System ready. Scan RFID cards...");
  Serial.println();
}

void loop()
{
  if (wifiMulti.run() == WL_CONNECTED)
  {
    if (!wifiConnected)
    {
      wifiConnected = true;
      Serial.println("WiFi reconnected!");
      ensureMQTT();
    }
    mqtt.loop();
    if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial())
      readRFID();
  }
  else
  {
    if (wifiConnected)
    {
      wifiConnected = false;
      Serial.println("WiFi disconnected!");
    }
    delay(2000);
    connectToWiFi();
  }
  delay(50);
}
